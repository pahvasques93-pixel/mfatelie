# MF Ateliê Gestão

Sistema simples de gestão para o MF Ateliê: vendas (entradas), despesas (saídas), produtos, estoque, materiais e precificação saudável.

É uma única página (`index.html`), sem instalação e sem servidor.

## Como publicar no GitHub Pages

1. Crie um repositório no GitHub (por exemplo, `mf-atelie-gestao`).
2. Envie os arquivos desta pasta (`index.html` e `README.md`) para a raiz do repositório.
3. No repositório, abra **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**, branch `main`, pasta `/ (root)`, e salve.
5. Em um ou dois minutos o sistema estará em `https://SEU-USUARIO.github.io/mf-atelie-gestao/`.

Pelo terminal:

```bash
git init
git add .
git commit -m "MF Ateliê Gestão"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/mf-atelie-gestao.git
git push -u origin main
```

## Onde ficam os dados

Os dados ficam guardados **no navegador de quem usa** (localStorage). Isso significa:

- cada aparelho/navegador tem os seus próprios dados;
- limpar os dados do navegador apaga os lançamentos;
- em **Ajustes → Cópia de segurança** dá para baixar um arquivo com tudo e restaurar em outro aparelho.

Ninguém que acesse o endereço vê os dados de outra pessoa, porque nada é enviado para a internet.

## Como o preço sugerido é calculado

```
valor da hora     = pró-labore desejado ÷ horas de trabalho no mês
custo fixo/hora   = custos fixos do mês ÷ horas de trabalho no mês
custo da peça     = materiais + tempo × (valor da hora + custo fixo/hora)
preço mínimo      = custo da peça ÷ (1 − taxa de pagamento)
preço sugerido    = custo da peça ÷ (1 − taxa de pagamento − margem de lucro)
```

- **Saudável**: o preço cobrado é igual ou maior que o sugerido.
- **Abaixo do ideal**: cobre os custos e a sua hora, mas não a margem.
- **Prejuízo**: está abaixo do preço mínimo.
